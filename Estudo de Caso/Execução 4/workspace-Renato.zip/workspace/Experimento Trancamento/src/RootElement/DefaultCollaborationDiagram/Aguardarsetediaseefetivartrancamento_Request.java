/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aguardarsetediaseefetivartrancamento Request</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getAguardarsetediaseefetivartrancamento_Request()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Aguardarsetediaseefetivartrancamento_Request extends EObject {
} // Aguardarsetediaseefetivartrancamento_Request
