/**
 */
package RootElement.DefaultCollaborationDiagram.impl;

import RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Request;
import RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Service;
import RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Request;
import RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Service;
import RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Request;
import RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Service;
import RootElement.DefaultCollaborationDiagram.CoordenadordoCurso;
import RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramFactory;
import RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage;
import RootElement.DefaultCollaborationDiagram.Discente;
import RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Request;
import RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Service;
import RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Request;
import RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Service;
import RootElement.DefaultCollaborationDiagram.Sistema;
import RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Request;
import RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Service;
import RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Request;
import RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Service;
import RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Request;
import RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Service;
import RootElement.DefaultCollaborationDiagram.solitacaodeferida_Request;
import RootElement.DefaultCollaborationDiagram.solitacaodeferida_Service;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DefaultCollaborationDiagramPackageImpl extends EPackageImpl implements DefaultCollaborationDiagramPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass iesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass coordenadordoCursoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass analisarsolicitacao_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cancelarsolicitacao_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cancelarsolicitacao_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solitacaodeferida_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solitacaodeferida_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solicitacaocancelada_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solicitacaocancelada_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sistemaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass naoepermitidosuspenderoprograma_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass analisarsolicitacao_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aguardarsetediaseefetivartrancamento_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aguardarsetediaseefetivartrancamento_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solicitacaoaprovada_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solicitacaoaprovada_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass oalunoestaemobservacao_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass oalunoestaemobservacao_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stringEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass discenteEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass naoepermitidosuspenderoprograma_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solicitartrancamento_ServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solicitartrancamento_RequestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType booleanEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType intEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DefaultCollaborationDiagramPackageImpl() {
		super(eNS_URI, DefaultCollaborationDiagramFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link DefaultCollaborationDiagramPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DefaultCollaborationDiagramPackage init() {
		if (isInited) return (DefaultCollaborationDiagramPackage)EPackage.Registry.INSTANCE.getEPackage(DefaultCollaborationDiagramPackage.eNS_URI);

		// Obtain or create and register package
		DefaultCollaborationDiagramPackageImpl theDefaultCollaborationDiagramPackage = (DefaultCollaborationDiagramPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof DefaultCollaborationDiagramPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new DefaultCollaborationDiagramPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theDefaultCollaborationDiagramPackage.createPackageContents();

		// Initialize created meta-data
		theDefaultCollaborationDiagramPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDefaultCollaborationDiagramPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(DefaultCollaborationDiagramPackage.eNS_URI, theDefaultCollaborationDiagramPackage);
		return theDefaultCollaborationDiagramPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIES() {
		return iesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCoordenadordoCurso() {
		return coordenadordoCursoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCoordenadordoCurso__Analisarsolicitacao() {
		return coordenadordoCursoEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCoordenadordoCurso__Cancelarsolicitacao() {
		return coordenadordoCursoEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAnalisarsolicitacao_Request() {
		return analisarsolicitacao_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCancelarsolicitacao_Service() {
		return cancelarsolicitacao_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCancelarsolicitacao_Request() {
		return cancelarsolicitacao_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getsolitacaodeferida_Service() {
		return solitacaodeferida_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getsolitacaodeferida_Request() {
		return solitacaodeferida_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolicitacaocancelada_Service() {
		return solicitacaocancelada_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolicitacaocancelada_Request() {
		return solicitacaocancelada_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSistema() {
		return sistemaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSistema__Verificarquantidadedetrancamentos__int_String() {
		return sistemaEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSistema__Aguardarsetediaseefetivartrancamento() {
		return sistemaEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSistema__Verificarnivelensino__int() {
		return sistemaEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSistema__Verificartempodecorridodadisciplina() {
		return sistemaEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNaoepermitidosuspenderoprograma_Service() {
		return naoepermitidosuspenderoprograma_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAnalisarsolicitacao_Service() {
		return analisarsolicitacao_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAguardarsetediaseefetivartrancamento_Service() {
		return aguardarsetediaseefetivartrancamento_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAguardarsetediaseefetivartrancamento_Request() {
		return aguardarsetediaseefetivartrancamento_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolicitacaoaprovada_Service() {
		return solicitacaoaprovada_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolicitacaoaprovada_Request() {
		return solicitacaoaprovada_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOalunoestaemobservacao_Service() {
		return oalunoestaemobservacao_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOalunoestaemobservacao_Request() {
		return oalunoestaemobservacao_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getString() {
		return stringEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiscente() {
		return discenteEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDiscente__Solicitartrancamento() {
		return discenteEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNaoepermitidosuspenderoprograma_Request() {
		return naoepermitidosuspenderoprograma_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolicitartrancamento_Service() {
		return solicitartrancamento_ServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolicitartrancamento_Request() {
		return solicitartrancamento_RequestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getboolean() {
		return booleanEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getint() {
		return intEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DefaultCollaborationDiagramFactory getDefaultCollaborationDiagramFactory() {
		return (DefaultCollaborationDiagramFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		iesEClass = createEClass(IES);

		coordenadordoCursoEClass = createEClass(COORDENADORDO_CURSO);
		createEOperation(coordenadordoCursoEClass, COORDENADORDO_CURSO___ANALISARSOLICITACAO);
		createEOperation(coordenadordoCursoEClass, COORDENADORDO_CURSO___CANCELARSOLICITACAO);

		analisarsolicitacao_RequestEClass = createEClass(ANALISARSOLICITACAO_REQUEST);

		cancelarsolicitacao_ServiceEClass = createEClass(CANCELARSOLICITACAO_SERVICE);

		cancelarsolicitacao_RequestEClass = createEClass(CANCELARSOLICITACAO_REQUEST);

		solitacaodeferida_ServiceEClass = createEClass(SOLITACAODEFERIDA_SERVICE);

		solitacaodeferida_RequestEClass = createEClass(SOLITACAODEFERIDA_REQUEST);

		solicitacaocancelada_ServiceEClass = createEClass(SOLICITACAOCANCELADA_SERVICE);

		solicitacaocancelada_RequestEClass = createEClass(SOLICITACAOCANCELADA_REQUEST);

		sistemaEClass = createEClass(SISTEMA);
		createEOperation(sistemaEClass, SISTEMA___VERIFICARQUANTIDADEDETRANCAMENTOS__INT_STRING);
		createEOperation(sistemaEClass, SISTEMA___AGUARDARSETEDIASEEFETIVARTRANCAMENTO);
		createEOperation(sistemaEClass, SISTEMA___VERIFICARNIVELENSINO__INT);
		createEOperation(sistemaEClass, SISTEMA___VERIFICARTEMPODECORRIDODADISCIPLINA);

		naoepermitidosuspenderoprograma_ServiceEClass = createEClass(NAOEPERMITIDOSUSPENDEROPROGRAMA_SERVICE);

		analisarsolicitacao_ServiceEClass = createEClass(ANALISARSOLICITACAO_SERVICE);

		aguardarsetediaseefetivartrancamento_ServiceEClass = createEClass(AGUARDARSETEDIASEEFETIVARTRANCAMENTO_SERVICE);

		aguardarsetediaseefetivartrancamento_RequestEClass = createEClass(AGUARDARSETEDIASEEFETIVARTRANCAMENTO_REQUEST);

		solicitacaoaprovada_ServiceEClass = createEClass(SOLICITACAOAPROVADA_SERVICE);

		solicitacaoaprovada_RequestEClass = createEClass(SOLICITACAOAPROVADA_REQUEST);

		oalunoestaemobservacao_ServiceEClass = createEClass(OALUNOESTAEMOBSERVACAO_SERVICE);

		oalunoestaemobservacao_RequestEClass = createEClass(OALUNOESTAEMOBSERVACAO_REQUEST);

		stringEClass = createEClass(STRING);

		discenteEClass = createEClass(DISCENTE);
		createEOperation(discenteEClass, DISCENTE___SOLICITARTRANCAMENTO);

		naoepermitidosuspenderoprograma_RequestEClass = createEClass(NAOEPERMITIDOSUSPENDEROPROGRAMA_REQUEST);

		solicitartrancamento_ServiceEClass = createEClass(SOLICITARTRANCAMENTO_SERVICE);

		solicitartrancamento_RequestEClass = createEClass(SOLICITARTRANCAMENTO_REQUEST);

		// Create data types
		booleanEDataType = createEDataType(BOOLEAN);
		intEDataType = createEDataType(INT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		coordenadordoCursoEClass.getESuperTypes().add(this.getIES());
		coordenadordoCursoEClass.getESuperTypes().add(this.getAnalisarsolicitacao_Request());
		coordenadordoCursoEClass.getESuperTypes().add(this.getCancelarsolicitacao_Service());
		coordenadordoCursoEClass.getESuperTypes().add(this.getCancelarsolicitacao_Request());
		coordenadordoCursoEClass.getESuperTypes().add(this.getsolitacaodeferida_Service());
		coordenadordoCursoEClass.getESuperTypes().add(this.getsolitacaodeferida_Request());
		coordenadordoCursoEClass.getESuperTypes().add(this.getSolicitacaocancelada_Service());
		coordenadordoCursoEClass.getESuperTypes().add(this.getSolicitacaocancelada_Request());
		sistemaEClass.getESuperTypes().add(this.getCoordenadordoCurso());
		sistemaEClass.getESuperTypes().add(this.getNaoepermitidosuspenderoprograma_Service());
		sistemaEClass.getESuperTypes().add(this.getAnalisarsolicitacao_Service());
		sistemaEClass.getESuperTypes().add(this.getAguardarsetediaseefetivartrancamento_Service());
		sistemaEClass.getESuperTypes().add(this.getAguardarsetediaseefetivartrancamento_Request());
		sistemaEClass.getESuperTypes().add(this.getSolicitacaoaprovada_Service());
		sistemaEClass.getESuperTypes().add(this.getSolicitacaoaprovada_Request());
		sistemaEClass.getESuperTypes().add(this.getOalunoestaemobservacao_Service());
		sistemaEClass.getESuperTypes().add(this.getOalunoestaemobservacao_Request());
		discenteEClass.getESuperTypes().add(this.getCoordenadordoCurso());
		discenteEClass.getESuperTypes().add(this.getNaoepermitidosuspenderoprograma_Request());
		discenteEClass.getESuperTypes().add(this.getSolicitartrancamento_Service());
		discenteEClass.getESuperTypes().add(this.getSolicitartrancamento_Request());

		// Initialize classes, features, and operations; add parameters
		initEClass(iesEClass, RootElement.DefaultCollaborationDiagram.IES.class, "IES", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(coordenadordoCursoEClass, CoordenadordoCurso.class, "CoordenadordoCurso", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getCoordenadordoCurso__Analisarsolicitacao(), null, "Analisarsolicitacao", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCoordenadordoCurso__Cancelarsolicitacao(), null, "Cancelarsolicitacao", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(analisarsolicitacao_RequestEClass, Analisarsolicitacao_Request.class, "Analisarsolicitacao_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(cancelarsolicitacao_ServiceEClass, Cancelarsolicitacao_Service.class, "Cancelarsolicitacao_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(cancelarsolicitacao_RequestEClass, Cancelarsolicitacao_Request.class, "Cancelarsolicitacao_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solitacaodeferida_ServiceEClass, solitacaodeferida_Service.class, "solitacaodeferida_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solitacaodeferida_RequestEClass, solitacaodeferida_Request.class, "solitacaodeferida_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solicitacaocancelada_ServiceEClass, Solicitacaocancelada_Service.class, "Solicitacaocancelada_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solicitacaocancelada_RequestEClass, Solicitacaocancelada_Request.class, "Solicitacaocancelada_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sistemaEClass, Sistema.class, "Sistema", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		EOperation op = initEOperation(getSistema__Verificarquantidadedetrancamentos__int_String(), this.getboolean(), "Verificarquantidadedetrancamentos", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, this.getint(), "matricula", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, this.getString(), "codigoDisciplina", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSistema__Aguardarsetediaseefetivartrancamento(), null, "Aguardarsetediaseefetivartrancamento", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getSistema__Verificarnivelensino__int(), this.getString(), "Verificarnivelensino", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, this.getint(), "matricula", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSistema__Verificartempodecorridodadisciplina(), null, "Verificartempodecorridodadisciplina", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(naoepermitidosuspenderoprograma_ServiceEClass, Naoepermitidosuspenderoprograma_Service.class, "Naoepermitidosuspenderoprograma_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(analisarsolicitacao_ServiceEClass, Analisarsolicitacao_Service.class, "Analisarsolicitacao_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(aguardarsetediaseefetivartrancamento_ServiceEClass, Aguardarsetediaseefetivartrancamento_Service.class, "Aguardarsetediaseefetivartrancamento_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(aguardarsetediaseefetivartrancamento_RequestEClass, Aguardarsetediaseefetivartrancamento_Request.class, "Aguardarsetediaseefetivartrancamento_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solicitacaoaprovada_ServiceEClass, Solicitacaoaprovada_Service.class, "Solicitacaoaprovada_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solicitacaoaprovada_RequestEClass, Solicitacaoaprovada_Request.class, "Solicitacaoaprovada_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(oalunoestaemobservacao_ServiceEClass, Oalunoestaemobservacao_Service.class, "Oalunoestaemobservacao_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(oalunoestaemobservacao_RequestEClass, Oalunoestaemobservacao_Request.class, "Oalunoestaemobservacao_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(stringEClass, RootElement.DefaultCollaborationDiagram.String.class, "String", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(discenteEClass, Discente.class, "Discente", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getDiscente__Solicitartrancamento(), null, "Solicitartrancamento", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(naoepermitidosuspenderoprograma_RequestEClass, Naoepermitidosuspenderoprograma_Request.class, "Naoepermitidosuspenderoprograma_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solicitartrancamento_ServiceEClass, Solicitartrancamento_Service.class, "Solicitartrancamento_Service", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solicitartrancamento_RequestEClass, Solicitartrancamento_Request.class, "Solicitartrancamento_Request", IS_ABSTRACT, IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize data types
		initEDataType(booleanEDataType, boolean.class, "boolean", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(intEDataType, int.class, "int", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/uml2/2.0.0/UML
		createUMLAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/uml2/2.0.0/UML</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createUMLAnnotations() {
		String source = "http://www.eclipse.org/uml2/2.0.0/UML";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "originalName", "Default Collaboration Diagram"
		   });	
		addAnnotation
		  (solitacaodeferida_ServiceEClass, 
		   source, 
		   new String[] {
			 "originalName", "solitacaodeferida?_Service"
		   });	
		addAnnotation
		  (solitacaodeferida_RequestEClass, 
		   source, 
		   new String[] {
			 "originalName", "solitacaodeferida?_Request"
		   });	
		addAnnotation
		  (oalunoestaemobservacao_ServiceEClass, 
		   source, 
		   new String[] {
			 "originalName", "Oalunoestaemobservacao?_Service"
		   });	
		addAnnotation
		  (oalunoestaemobservacao_RequestEClass, 
		   source, 
		   new String[] {
			 "originalName", "Oalunoestaemobservacao?_Request"
		   });
	}

} //DefaultCollaborationDiagramPackageImpl
