/**
 */
package RootElement.DefaultCollaborationDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sistema</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getSistema()
 * @model
 * @generated
 */
public interface Sistema extends CoordenadordoCurso, Naoepermitidosuspenderoprograma_Service, Analisarsolicitacao_Service, Aguardarsetediaseefetivartrancamento_Service, Aguardarsetediaseefetivartrancamento_Request, Solicitacaoaprovada_Service, Solicitacaoaprovada_Request, Oalunoestaemobservacao_Service, Oalunoestaemobservacao_Request {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="RootElement.DefaultCollaborationDiagram.boolean" required="true" ordered="false" matriculaDataType="RootElement.DefaultCollaborationDiagram.int" matriculaRequired="true" matriculaOrdered="false" codigoDisciplinaRequired="true" codigoDisciplinaOrdered="false"
	 * @generated
	 */
	boolean Verificarquantidadedetrancamentos(int matricula, RootElement.DefaultCollaborationDiagram.String codigoDisciplina);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Aguardarsetediaseefetivartrancamento();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model required="true" ordered="false" matriculaDataType="RootElement.DefaultCollaborationDiagram.int" matriculaRequired="true" matriculaOrdered="false"
	 * @generated
	 */
	RootElement.DefaultCollaborationDiagram.String Verificarnivelensino(int matricula);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificartempodecorridodadisciplina();

} // Sistema
