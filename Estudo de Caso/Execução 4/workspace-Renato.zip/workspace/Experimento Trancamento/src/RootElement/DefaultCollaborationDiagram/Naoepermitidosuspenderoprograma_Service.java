/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Naoepermitidosuspenderoprograma Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getNaoepermitidosuspenderoprograma_Service()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Naoepermitidosuspenderoprograma_Service extends EObject {
} // Naoepermitidosuspenderoprograma_Service
