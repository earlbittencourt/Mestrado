/**
 */
package RootElement.DefaultCollaborationDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coordenadordo Curso</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getCoordenadordoCurso()
 * @model abstract="true"
 * @generated
 */
public interface CoordenadordoCurso extends IES, Analisarsolicitacao_Request, Cancelarsolicitacao_Service, Cancelarsolicitacao_Request, solitacaodeferida_Service, solitacaodeferida_Request, Solicitacaocancelada_Service, Solicitacaocancelada_Request {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Analisarsolicitacao();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Cancelarsolicitacao();

} // CoordenadordoCurso
