/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cancelarsolicitacao Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getCancelarsolicitacao_Service()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Cancelarsolicitacao_Service extends EObject {
} // Cancelarsolicitacao_Service
