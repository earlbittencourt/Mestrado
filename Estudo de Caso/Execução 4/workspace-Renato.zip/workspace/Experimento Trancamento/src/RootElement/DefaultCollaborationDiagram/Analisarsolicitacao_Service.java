/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analisarsolicitacao Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getAnalisarsolicitacao_Service()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Analisarsolicitacao_Service extends EObject {
} // Analisarsolicitacao_Service
