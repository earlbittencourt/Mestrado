/**
 */
package RootElement.DefaultCollaborationDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sistema</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getSistema()
 * @model
 * @generated
 */
public interface Sistema extends IES, Aguardarsetediaseefetivartrancamento_Service, Aguardarsetediaseefetivartrancamento_Request, Solicitacaoaprovada_Service, Solicitacaoaprovada_Request, Naoepermitidosuspenderoprograma_Service, Analisarsolicitacao_Service, Oalunoestaemobservacao_Service, Oalunoestaemobservacao_Request {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="RootElement.DefaultCollaborationDiagram.boolean" required="true" ordered="false" matriculaDataType="RootElement.DefaultCollaborationDiagram.int" matriculaRequired="true" matriculaOrdered="false" codigoDisciplinaDataType="RootElement.DefaultCollaborationDiagram.String" codigoDisciplinaRequired="true" codigoDisciplinaOrdered="false"
	 * @generated
	 */
	boolean Verificarquantidadedetrancamentos(int matricula, Object codigoDisciplina);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarsolicitacao();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Aguardarsetediaseefetivartrancamento();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Apresentadadosdoaluno();

} // Sistema
