/**
 */
package RootElement.DefaultCollaborationDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coordenadordo Curso</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getCoordenadordoCurso()
 * @model
 * @generated
 */
public interface CoordenadordoCurso extends IES, Analisarsolicitacao_Request, solitacaodeferida_Service, solitacaodeferida_Request, Solicitacaocancelada_Service, Solicitacaocancelada_Request {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Cancelarsolicitacao();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="RootElement.DefaultCollaborationDiagram.String" required="true" ordered="false" parametromatriculaDataType="RootElement.DefaultCollaborationDiagram.int" parametromatriculaRequired="true" parametromatriculaOrdered="false"
	 *        parametromatriculaAnnotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='parametro matricula'"
	 * @generated
	 */
	Object Verificarniveldeensino(int parametromatricula);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Analisarsolicitacao();

} // CoordenadordoCurso
