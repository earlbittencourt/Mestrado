/**
 */
package RootElement.DefaultCollaborationDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Discente</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getDiscente()
 * @model
 * @generated
 */
public interface Discente extends IES, Naoepermitidosuspenderoprograma_Request, Solicitartrancamento_Service, Solicitartrancamento_Request {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Solicitartrancamento();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Selecionarcomponentecurricular();

} // Discente
