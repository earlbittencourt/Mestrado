/**
 */
package RootElement.DefaultCollaborationDiagram.impl;

import RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage;
import RootElement.DefaultCollaborationDiagram.Sistema;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sistema</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SistemaImpl extends IESImpl implements Sistema {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SistemaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DefaultCollaborationDiagramPackage.Literals.SISTEMA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Verificarquantidadedetrancamentos(int matricula, Object codigoDisciplina) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Verificarsolicitacao() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Aguardarsetediaseefetivartrancamento() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Apresentadadosdoaluno() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case DefaultCollaborationDiagramPackage.SISTEMA___VERIFICARQUANTIDADEDETRANCAMENTOS__INT_STRING:
				return Verificarquantidadedetrancamentos((Integer)arguments.get(0), (Object)arguments.get(1));
			case DefaultCollaborationDiagramPackage.SISTEMA___VERIFICARSOLICITACAO:
				Verificarsolicitacao();
				return null;
			case DefaultCollaborationDiagramPackage.SISTEMA___AGUARDARSETEDIASEEFETIVARTRANCAMENTO:
				Aguardarsetediaseefetivartrancamento();
				return null;
			case DefaultCollaborationDiagramPackage.SISTEMA___APRESENTADADOSDOALUNO:
				Apresentadadosdoaluno();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //SistemaImpl
