/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Oalunoestaemobservacao Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getOalunoestaemobservacao_Service()
 * @model interface="true" abstract="true"
 *        annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='Oalunoestaemobservacao?_Service'"
 * @generated
 */
public interface Oalunoestaemobservacao_Service extends EObject {
} // Oalunoestaemobservacao_Service
