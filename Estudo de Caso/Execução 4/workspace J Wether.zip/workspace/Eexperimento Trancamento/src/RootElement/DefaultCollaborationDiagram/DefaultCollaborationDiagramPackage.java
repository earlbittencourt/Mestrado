/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='Default Collaboration Diagram'"
 * @generated
 */
public interface DefaultCollaborationDiagramPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "DefaultCollaborationDiagram";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///RootElement/DefaultCollaborationDiagram.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "RootElement.DefaultCollaborationDiagram";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DefaultCollaborationDiagramPackage eINSTANCE = RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl.init();

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.impl.IESImpl <em>IES</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.impl.IESImpl
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getIES()
	 * @generated
	 */
	int IES = 0;

	/**
	 * The number of structural features of the '<em>IES</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IES_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>IES</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.impl.DiscenteImpl <em>Discente</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.impl.DiscenteImpl
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getDiscente()
	 * @generated
	 */
	int DISCENTE = 1;

	/**
	 * The number of structural features of the '<em>Discente</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCENTE_FEATURE_COUNT = IES_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Solicitartrancamento</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCENTE___SOLICITARTRANCAMENTO = IES_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Discente</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCENTE_OPERATION_COUNT = IES_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Request <em>Naoepermitidosuspenderoprograma Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getNaoepermitidosuspenderoprograma_Request()
	 * @generated
	 */
	int NAOEPERMITIDOSUSPENDEROPROGRAMA_REQUEST = 2;

	/**
	 * The number of structural features of the '<em>Naoepermitidosuspenderoprograma Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAOEPERMITIDOSUSPENDEROPROGRAMA_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Naoepermitidosuspenderoprograma Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAOEPERMITIDOSUSPENDEROPROGRAMA_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Verificarsolicitacao_Service <em>Verificarsolicitacao Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Verificarsolicitacao_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getVerificarsolicitacao_Service()
	 * @generated
	 */
	int VERIFICARSOLICITACAO_SERVICE = 3;

	/**
	 * The number of structural features of the '<em>Verificarsolicitacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERIFICARSOLICITACAO_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Verificarsolicitacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERIFICARSOLICITACAO_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Request <em>Solicitartrancamento Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitartrancamento_Request()
	 * @generated
	 */
	int SOLICITARTRANCAMENTO_REQUEST = 4;

	/**
	 * The number of structural features of the '<em>Solicitartrancamento Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITARTRANCAMENTO_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Solicitartrancamento Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITARTRANCAMENTO_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.impl.SistemaImpl <em>Sistema</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.impl.SistemaImpl
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSistema()
	 * @generated
	 */
	int SISTEMA = 5;

	/**
	 * The number of structural features of the '<em>Sistema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA_FEATURE_COUNT = DISCENTE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Solicitartrancamento</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___SOLICITARTRANCAMENTO = DISCENTE___SOLICITARTRANCAMENTO;

	/**
	 * The operation id for the '<em>Verificarquantidadedetrancamentos</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___VERIFICARQUANTIDADEDETRANCAMENTOS__INT_STRING = DISCENTE_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Verificarseeoalunoeformandoeativo</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___VERIFICARSEEOALUNOEFORMANDOEATIVO = DISCENTE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Aguardarsetediaseefetivartrancamento</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___AGUARDARSETEDIASEEFETIVARTRANCAMENTO = DISCENTE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Verificarnivelensino</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___VERIFICARNIVELENSINO__INT = DISCENTE_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>Verificarsolicitacao</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___VERIFICARSOLICITACAO = DISCENTE_OPERATION_COUNT + 4;

	/**
	 * The operation id for the '<em>Verificarnivelestudante</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___VERIFICARNIVELESTUDANTE = DISCENTE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Verificartempodecorrido</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA___VERIFICARTEMPODECORRIDO = DISCENTE_OPERATION_COUNT + 6;

	/**
	 * The number of operations of the '<em>Sistema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SISTEMA_OPERATION_COUNT = DISCENTE_OPERATION_COUNT + 7;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Service <em>Oalunoestaemobservacao Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getOalunoestaemobservacao_Service()
	 * @generated
	 */
	int OALUNOESTAEMOBSERVACAO_SERVICE = 6;

	/**
	 * The number of structural features of the '<em>Oalunoestaemobservacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OALUNOESTAEMOBSERVACAO_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Oalunoestaemobservacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OALUNOESTAEMOBSERVACAO_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Request <em>Oalunoestaemobservacao Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getOalunoestaemobservacao_Request()
	 * @generated
	 */
	int OALUNOESTAEMOBSERVACAO_REQUEST = 7;

	/**
	 * The number of structural features of the '<em>Oalunoestaemobservacao Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OALUNOESTAEMOBSERVACAO_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Oalunoestaemobservacao Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OALUNOESTAEMOBSERVACAO_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Disciplina_Request <em>Disciplina Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Disciplina_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getDisciplina_Request()
	 * @generated
	 */
	int DISCIPLINA_REQUEST = 8;

	/**
	 * The number of structural features of the '<em>Disciplina Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCIPLINA_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Disciplina Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCIPLINA_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Service <em>�permitidosuspenderoprograma Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#get�permitidosuspenderoprograma_Service()
	 * @generated
	 */
	int �PERMITIDOSUSPENDEROPROGRAMA_SERVICE = 9;

	/**
	 * The number of structural features of the '<em>�permitidosuspenderoprograma Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int �PERMITIDOSUSPENDEROPROGRAMA_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>�permitidosuspenderoprograma Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int �PERMITIDOSUSPENDEROPROGRAMA_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Request <em>�permitidosuspenderoprograma Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#get�permitidosuspenderoprograma_Request()
	 * @generated
	 */
	int �PERMITIDOSUSPENDEROPROGRAMA_REQUEST = 10;

	/**
	 * The number of structural features of the '<em>�permitidosuspenderoprograma Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int �PERMITIDOSUSPENDEROPROGRAMA_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>�permitidosuspenderoprograma Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int �PERMITIDOSUSPENDEROPROGRAMA_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Matricula_Request <em>Matricula Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Matricula_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getMatricula_Request()
	 * @generated
	 */
	int MATRICULA_REQUEST = 11;

	/**
	 * The number of structural features of the '<em>Matricula Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATRICULA_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Matricula Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATRICULA_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Service <em>Naoepermitidosuspenderoprograma Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getNaoepermitidosuspenderoprograma_Service()
	 * @generated
	 */
	int NAOEPERMITIDOSUSPENDEROPROGRAMA_SERVICE = 12;

	/**
	 * The number of structural features of the '<em>Naoepermitidosuspenderoprograma Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAOEPERMITIDOSUSPENDEROPROGRAMA_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Naoepermitidosuspenderoprograma Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAOEPERMITIDOSUSPENDEROPROGRAMA_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Atividade_Request <em>Atividade Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Atividade_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAtividade_Request()
	 * @generated
	 */
	int ATIVIDADE_REQUEST = 13;

	/**
	 * The number of structural features of the '<em>Atividade Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATIVIDADE_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Atividade Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATIVIDADE_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Service <em>Solicitacaoaprovada Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaoaprovada_Service()
	 * @generated
	 */
	int SOLICITACAOAPROVADA_SERVICE = 14;

	/**
	 * The number of structural features of the '<em>Solicitacaoaprovada Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOAPROVADA_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Solicitacaoaprovada Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOAPROVADA_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Request <em>Solicitacaoaprovada Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaoaprovada_Request()
	 * @generated
	 */
	int SOLICITACAOAPROVADA_REQUEST = 15;

	/**
	 * The number of structural features of the '<em>Solicitacaoaprovada Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOAPROVADA_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Solicitacaoaprovada Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOAPROVADA_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Service <em>Analisarsolicitacao Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAnalisarsolicitacao_Service()
	 * @generated
	 */
	int ANALISARSOLICITACAO_SERVICE = 16;

	/**
	 * The number of structural features of the '<em>Analisarsolicitacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALISARSOLICITACAO_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Analisarsolicitacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALISARSOLICITACAO_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Service <em>Aguardarsetediaseefetivartrancamento Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAguardarsetediaseefetivartrancamento_Service()
	 * @generated
	 */
	int AGUARDARSETEDIASEEFETIVARTRANCAMENTO_SERVICE = 17;

	/**
	 * The number of structural features of the '<em>Aguardarsetediaseefetivartrancamento Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGUARDARSETEDIASEEFETIVARTRANCAMENTO_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Aguardarsetediaseefetivartrancamento Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGUARDARSETEDIASEEFETIVARTRANCAMENTO_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Request <em>Aguardarsetediaseefetivartrancamento Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAguardarsetediaseefetivartrancamento_Request()
	 * @generated
	 */
	int AGUARDARSETEDIASEEFETIVARTRANCAMENTO_REQUEST = 18;

	/**
	 * The number of structural features of the '<em>Aguardarsetediaseefetivartrancamento Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGUARDARSETEDIASEEFETIVARTRANCAMENTO_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Aguardarsetediaseefetivartrancamento Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGUARDARSETEDIASEEFETIVARTRANCAMENTO_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.impl.CoordenadordoCursoImpl <em>Coordenadordo Curso</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.impl.CoordenadordoCursoImpl
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getCoordenadordoCurso()
	 * @generated
	 */
	int COORDENADORDO_CURSO = 19;

	/**
	 * The number of structural features of the '<em>Coordenadordo Curso</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDENADORDO_CURSO_FEATURE_COUNT = IES_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Cancelarsolicitacao</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDENADORDO_CURSO___CANCELARSOLICITACAO = IES_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Analisarsolicitacao</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDENADORDO_CURSO___ANALISARSOLICITACAO = IES_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Coordenadordo Curso</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COORDENADORDO_CURSO_OPERATION_COUNT = IES_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.solitacaodeferida_Service <em>solitacaodeferida Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.solitacaodeferida_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getsolitacaodeferida_Service()
	 * @generated
	 */
	int SOLITACAODEFERIDA_SERVICE = 20;

	/**
	 * The number of structural features of the '<em>solitacaodeferida Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLITACAODEFERIDA_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>solitacaodeferida Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLITACAODEFERIDA_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.solitacaodeferida_Request <em>solitacaodeferida Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.solitacaodeferida_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getsolitacaodeferida_Request()
	 * @generated
	 */
	int SOLITACAODEFERIDA_REQUEST = 21;

	/**
	 * The number of structural features of the '<em>solitacaodeferida Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLITACAODEFERIDA_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>solitacaodeferida Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLITACAODEFERIDA_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Service <em>Solicitacaocancelada Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaocancelada_Service()
	 * @generated
	 */
	int SOLICITACAOCANCELADA_SERVICE = 22;

	/**
	 * The number of structural features of the '<em>Solicitacaocancelada Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOCANCELADA_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Solicitacaocancelada Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOCANCELADA_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Request <em>Solicitacaocancelada Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaocancelada_Request()
	 * @generated
	 */
	int SOLICITACAOCANCELADA_REQUEST = 23;

	/**
	 * The number of structural features of the '<em>Solicitacaocancelada Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOCANCELADA_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Solicitacaocancelada Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLICITACAOCANCELADA_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Request <em>Analisarsolicitacao Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAnalisarsolicitacao_Request()
	 * @generated
	 */
	int ANALISARSOLICITACAO_REQUEST = 24;

	/**
	 * The number of structural features of the '<em>Analisarsolicitacao Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALISARSOLICITACAO_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Analisarsolicitacao Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALISARSOLICITACAO_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Service <em>Cancelarsolicitacao Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Service
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getCancelarsolicitacao_Service()
	 * @generated
	 */
	int CANCELARSOLICITACAO_SERVICE = 25;

	/**
	 * The number of structural features of the '<em>Cancelarsolicitacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CANCELARSOLICITACAO_SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Cancelarsolicitacao Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CANCELARSOLICITACAO_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Request <em>Cancelarsolicitacao Request</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Request
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getCancelarsolicitacao_Request()
	 * @generated
	 */
	int CANCELARSOLICITACAO_REQUEST = 26;

	/**
	 * The number of structural features of the '<em>Cancelarsolicitacao Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CANCELARSOLICITACAO_REQUEST_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Cancelarsolicitacao Request</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CANCELARSOLICITACAO_REQUEST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '<em>int</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getint()
	 * @generated
	 */
	int INT = 27;


	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.IES <em>IES</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IES</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.IES
	 * @generated
	 */
	EClass getIES();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Discente <em>Discente</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Discente</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Discente
	 * @generated
	 */
	EClass getDiscente();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Discente#Solicitartrancamento() <em>Solicitartrancamento</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Solicitartrancamento</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Discente#Solicitartrancamento()
	 * @generated
	 */
	EOperation getDiscente__Solicitartrancamento();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Request <em>Naoepermitidosuspenderoprograma Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Naoepermitidosuspenderoprograma Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Request
	 * @generated
	 */
	EClass getNaoepermitidosuspenderoprograma_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Verificarsolicitacao_Service <em>Verificarsolicitacao Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Verificarsolicitacao Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Verificarsolicitacao_Service
	 * @generated
	 */
	EClass getVerificarsolicitacao_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Request <em>Solicitartrancamento Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solicitartrancamento Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Request
	 * @generated
	 */
	EClass getSolicitartrancamento_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Sistema <em>Sistema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sistema</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema
	 * @generated
	 */
	EClass getSistema();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Sistema#Verificarquantidadedetrancamentos(int, String) <em>Verificarquantidadedetrancamentos</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Verificarquantidadedetrancamentos</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema#Verificarquantidadedetrancamentos(int, String)
	 * @generated
	 */
	EOperation getSistema__Verificarquantidadedetrancamentos__int_String();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Sistema#Verificarseeoalunoeformandoeativo() <em>Verificarseeoalunoeformandoeativo</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Verificarseeoalunoeformandoeativo</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema#Verificarseeoalunoeformandoeativo()
	 * @generated
	 */
	EOperation getSistema__Verificarseeoalunoeformandoeativo();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Sistema#Aguardarsetediaseefetivartrancamento() <em>Aguardarsetediaseefetivartrancamento</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Aguardarsetediaseefetivartrancamento</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema#Aguardarsetediaseefetivartrancamento()
	 * @generated
	 */
	EOperation getSistema__Aguardarsetediaseefetivartrancamento();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Sistema#Verificarnivelensino(int) <em>Verificarnivelensino</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Verificarnivelensino</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema#Verificarnivelensino(int)
	 * @generated
	 */
	EOperation getSistema__Verificarnivelensino__int();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Sistema#Verificarsolicitacao() <em>Verificarsolicitacao</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Verificarsolicitacao</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema#Verificarsolicitacao()
	 * @generated
	 */
	EOperation getSistema__Verificarsolicitacao();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Sistema#Verificarnivelestudante() <em>Verificarnivelestudante</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Verificarnivelestudante</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema#Verificarnivelestudante()
	 * @generated
	 */
	EOperation getSistema__Verificarnivelestudante();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.Sistema#Verificartempodecorrido() <em>Verificartempodecorrido</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Verificartempodecorrido</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.Sistema#Verificartempodecorrido()
	 * @generated
	 */
	EOperation getSistema__Verificartempodecorrido();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Service <em>Oalunoestaemobservacao Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Oalunoestaemobservacao Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Service
	 * @generated
	 */
	EClass getOalunoestaemobservacao_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Request <em>Oalunoestaemobservacao Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Oalunoestaemobservacao Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Request
	 * @generated
	 */
	EClass getOalunoestaemobservacao_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Disciplina_Request <em>Disciplina Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Disciplina Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Disciplina_Request
	 * @generated
	 */
	EClass getDisciplina_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Service <em>�permitidosuspenderoprograma Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>�permitidosuspenderoprograma Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Service
	 * @generated
	 */
	EClass get�permitidosuspenderoprograma_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Request <em>�permitidosuspenderoprograma Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>�permitidosuspenderoprograma Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Request
	 * @generated
	 */
	EClass get�permitidosuspenderoprograma_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Matricula_Request <em>Matricula Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Matricula Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Matricula_Request
	 * @generated
	 */
	EClass getMatricula_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Service <em>Naoepermitidosuspenderoprograma Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Naoepermitidosuspenderoprograma Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Service
	 * @generated
	 */
	EClass getNaoepermitidosuspenderoprograma_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Atividade_Request <em>Atividade Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Atividade Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Atividade_Request
	 * @generated
	 */
	EClass getAtividade_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Service <em>Solicitacaoaprovada Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solicitacaoaprovada Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Service
	 * @generated
	 */
	EClass getSolicitacaoaprovada_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Request <em>Solicitacaoaprovada Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solicitacaoaprovada Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Request
	 * @generated
	 */
	EClass getSolicitacaoaprovada_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Service <em>Analisarsolicitacao Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Analisarsolicitacao Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Service
	 * @generated
	 */
	EClass getAnalisarsolicitacao_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Service <em>Aguardarsetediaseefetivartrancamento Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aguardarsetediaseefetivartrancamento Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Service
	 * @generated
	 */
	EClass getAguardarsetediaseefetivartrancamento_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Request <em>Aguardarsetediaseefetivartrancamento Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aguardarsetediaseefetivartrancamento Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Request
	 * @generated
	 */
	EClass getAguardarsetediaseefetivartrancamento_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.CoordenadordoCurso <em>Coordenadordo Curso</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Coordenadordo Curso</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.CoordenadordoCurso
	 * @generated
	 */
	EClass getCoordenadordoCurso();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.CoordenadordoCurso#Cancelarsolicitacao() <em>Cancelarsolicitacao</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Cancelarsolicitacao</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.CoordenadordoCurso#Cancelarsolicitacao()
	 * @generated
	 */
	EOperation getCoordenadordoCurso__Cancelarsolicitacao();

	/**
	 * Returns the meta object for the '{@link RootElement.DefaultCollaborationDiagram.CoordenadordoCurso#Analisarsolicitacao() <em>Analisarsolicitacao</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Analisarsolicitacao</em>' operation.
	 * @see RootElement.DefaultCollaborationDiagram.CoordenadordoCurso#Analisarsolicitacao()
	 * @generated
	 */
	EOperation getCoordenadordoCurso__Analisarsolicitacao();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.solitacaodeferida_Service <em>solitacaodeferida Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>solitacaodeferida Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.solitacaodeferida_Service
	 * @generated
	 */
	EClass getsolitacaodeferida_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.solitacaodeferida_Request <em>solitacaodeferida Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>solitacaodeferida Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.solitacaodeferida_Request
	 * @generated
	 */
	EClass getsolitacaodeferida_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Service <em>Solicitacaocancelada Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solicitacaocancelada Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Service
	 * @generated
	 */
	EClass getSolicitacaocancelada_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Request <em>Solicitacaocancelada Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solicitacaocancelada Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Request
	 * @generated
	 */
	EClass getSolicitacaocancelada_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Request <em>Analisarsolicitacao Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Analisarsolicitacao Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Request
	 * @generated
	 */
	EClass getAnalisarsolicitacao_Request();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Service <em>Cancelarsolicitacao Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cancelarsolicitacao Service</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Service
	 * @generated
	 */
	EClass getCancelarsolicitacao_Service();

	/**
	 * Returns the meta object for class '{@link RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Request <em>Cancelarsolicitacao Request</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cancelarsolicitacao Request</em>'.
	 * @see RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Request
	 * @generated
	 */
	EClass getCancelarsolicitacao_Request();

	/**
	 * Returns the meta object for data type '<em>int</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>int</em>'.
	 * @model instanceClass="int"
	 * @generated
	 */
	EDataType getint();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DefaultCollaborationDiagramFactory getDefaultCollaborationDiagramFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.impl.IESImpl <em>IES</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.impl.IESImpl
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getIES()
		 * @generated
		 */
		EClass IES = eINSTANCE.getIES();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.impl.DiscenteImpl <em>Discente</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.impl.DiscenteImpl
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getDiscente()
		 * @generated
		 */
		EClass DISCENTE = eINSTANCE.getDiscente();

		/**
		 * The meta object literal for the '<em><b>Solicitartrancamento</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DISCENTE___SOLICITARTRANCAMENTO = eINSTANCE.getDiscente__Solicitartrancamento();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Request <em>Naoepermitidosuspenderoprograma Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getNaoepermitidosuspenderoprograma_Request()
		 * @generated
		 */
		EClass NAOEPERMITIDOSUSPENDEROPROGRAMA_REQUEST = eINSTANCE.getNaoepermitidosuspenderoprograma_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Verificarsolicitacao_Service <em>Verificarsolicitacao Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Verificarsolicitacao_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getVerificarsolicitacao_Service()
		 * @generated
		 */
		EClass VERIFICARSOLICITACAO_SERVICE = eINSTANCE.getVerificarsolicitacao_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Request <em>Solicitartrancamento Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Solicitartrancamento_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitartrancamento_Request()
		 * @generated
		 */
		EClass SOLICITARTRANCAMENTO_REQUEST = eINSTANCE.getSolicitartrancamento_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.impl.SistemaImpl <em>Sistema</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.impl.SistemaImpl
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSistema()
		 * @generated
		 */
		EClass SISTEMA = eINSTANCE.getSistema();

		/**
		 * The meta object literal for the '<em><b>Verificarquantidadedetrancamentos</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SISTEMA___VERIFICARQUANTIDADEDETRANCAMENTOS__INT_STRING = eINSTANCE.getSistema__Verificarquantidadedetrancamentos__int_String();

		/**
		 * The meta object literal for the '<em><b>Verificarseeoalunoeformandoeativo</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SISTEMA___VERIFICARSEEOALUNOEFORMANDOEATIVO = eINSTANCE.getSistema__Verificarseeoalunoeformandoeativo();

		/**
		 * The meta object literal for the '<em><b>Aguardarsetediaseefetivartrancamento</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SISTEMA___AGUARDARSETEDIASEEFETIVARTRANCAMENTO = eINSTANCE.getSistema__Aguardarsetediaseefetivartrancamento();

		/**
		 * The meta object literal for the '<em><b>Verificarnivelensino</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SISTEMA___VERIFICARNIVELENSINO__INT = eINSTANCE.getSistema__Verificarnivelensino__int();

		/**
		 * The meta object literal for the '<em><b>Verificarsolicitacao</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SISTEMA___VERIFICARSOLICITACAO = eINSTANCE.getSistema__Verificarsolicitacao();

		/**
		 * The meta object literal for the '<em><b>Verificarnivelestudante</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SISTEMA___VERIFICARNIVELESTUDANTE = eINSTANCE.getSistema__Verificarnivelestudante();

		/**
		 * The meta object literal for the '<em><b>Verificartempodecorrido</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SISTEMA___VERIFICARTEMPODECORRIDO = eINSTANCE.getSistema__Verificartempodecorrido();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Service <em>Oalunoestaemobservacao Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getOalunoestaemobservacao_Service()
		 * @generated
		 */
		EClass OALUNOESTAEMOBSERVACAO_SERVICE = eINSTANCE.getOalunoestaemobservacao_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Request <em>Oalunoestaemobservacao Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Oalunoestaemobservacao_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getOalunoestaemobservacao_Request()
		 * @generated
		 */
		EClass OALUNOESTAEMOBSERVACAO_REQUEST = eINSTANCE.getOalunoestaemobservacao_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Disciplina_Request <em>Disciplina Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Disciplina_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getDisciplina_Request()
		 * @generated
		 */
		EClass DISCIPLINA_REQUEST = eINSTANCE.getDisciplina_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Service <em>�permitidosuspenderoprograma Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#get�permitidosuspenderoprograma_Service()
		 * @generated
		 */
		EClass �PERMITIDOSUSPENDEROPROGRAMA_SERVICE = eINSTANCE.get�permitidosuspenderoprograma_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Request <em>�permitidosuspenderoprograma Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.�permitidosuspenderoprograma_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#get�permitidosuspenderoprograma_Request()
		 * @generated
		 */
		EClass �PERMITIDOSUSPENDEROPROGRAMA_REQUEST = eINSTANCE.get�permitidosuspenderoprograma_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Matricula_Request <em>Matricula Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Matricula_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getMatricula_Request()
		 * @generated
		 */
		EClass MATRICULA_REQUEST = eINSTANCE.getMatricula_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Service <em>Naoepermitidosuspenderoprograma Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Naoepermitidosuspenderoprograma_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getNaoepermitidosuspenderoprograma_Service()
		 * @generated
		 */
		EClass NAOEPERMITIDOSUSPENDEROPROGRAMA_SERVICE = eINSTANCE.getNaoepermitidosuspenderoprograma_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Atividade_Request <em>Atividade Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Atividade_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAtividade_Request()
		 * @generated
		 */
		EClass ATIVIDADE_REQUEST = eINSTANCE.getAtividade_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Service <em>Solicitacaoaprovada Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaoaprovada_Service()
		 * @generated
		 */
		EClass SOLICITACAOAPROVADA_SERVICE = eINSTANCE.getSolicitacaoaprovada_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Request <em>Solicitacaoaprovada Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Solicitacaoaprovada_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaoaprovada_Request()
		 * @generated
		 */
		EClass SOLICITACAOAPROVADA_REQUEST = eINSTANCE.getSolicitacaoaprovada_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Service <em>Analisarsolicitacao Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAnalisarsolicitacao_Service()
		 * @generated
		 */
		EClass ANALISARSOLICITACAO_SERVICE = eINSTANCE.getAnalisarsolicitacao_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Service <em>Aguardarsetediaseefetivartrancamento Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAguardarsetediaseefetivartrancamento_Service()
		 * @generated
		 */
		EClass AGUARDARSETEDIASEEFETIVARTRANCAMENTO_SERVICE = eINSTANCE.getAguardarsetediaseefetivartrancamento_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Request <em>Aguardarsetediaseefetivartrancamento Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Aguardarsetediaseefetivartrancamento_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAguardarsetediaseefetivartrancamento_Request()
		 * @generated
		 */
		EClass AGUARDARSETEDIASEEFETIVARTRANCAMENTO_REQUEST = eINSTANCE.getAguardarsetediaseefetivartrancamento_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.impl.CoordenadordoCursoImpl <em>Coordenadordo Curso</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.impl.CoordenadordoCursoImpl
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getCoordenadordoCurso()
		 * @generated
		 */
		EClass COORDENADORDO_CURSO = eINSTANCE.getCoordenadordoCurso();

		/**
		 * The meta object literal for the '<em><b>Cancelarsolicitacao</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation COORDENADORDO_CURSO___CANCELARSOLICITACAO = eINSTANCE.getCoordenadordoCurso__Cancelarsolicitacao();

		/**
		 * The meta object literal for the '<em><b>Analisarsolicitacao</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation COORDENADORDO_CURSO___ANALISARSOLICITACAO = eINSTANCE.getCoordenadordoCurso__Analisarsolicitacao();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.solitacaodeferida_Service <em>solitacaodeferida Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.solitacaodeferida_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getsolitacaodeferida_Service()
		 * @generated
		 */
		EClass SOLITACAODEFERIDA_SERVICE = eINSTANCE.getsolitacaodeferida_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.solitacaodeferida_Request <em>solitacaodeferida Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.solitacaodeferida_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getsolitacaodeferida_Request()
		 * @generated
		 */
		EClass SOLITACAODEFERIDA_REQUEST = eINSTANCE.getsolitacaodeferida_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Service <em>Solicitacaocancelada Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaocancelada_Service()
		 * @generated
		 */
		EClass SOLICITACAOCANCELADA_SERVICE = eINSTANCE.getSolicitacaocancelada_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Request <em>Solicitacaocancelada Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Solicitacaocancelada_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getSolicitacaocancelada_Request()
		 * @generated
		 */
		EClass SOLICITACAOCANCELADA_REQUEST = eINSTANCE.getSolicitacaocancelada_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Request <em>Analisarsolicitacao Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Analisarsolicitacao_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getAnalisarsolicitacao_Request()
		 * @generated
		 */
		EClass ANALISARSOLICITACAO_REQUEST = eINSTANCE.getAnalisarsolicitacao_Request();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Service <em>Cancelarsolicitacao Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Service
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getCancelarsolicitacao_Service()
		 * @generated
		 */
		EClass CANCELARSOLICITACAO_SERVICE = eINSTANCE.getCancelarsolicitacao_Service();

		/**
		 * The meta object literal for the '{@link RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Request <em>Cancelarsolicitacao Request</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.Cancelarsolicitacao_Request
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getCancelarsolicitacao_Request()
		 * @generated
		 */
		EClass CANCELARSOLICITACAO_REQUEST = eINSTANCE.getCancelarsolicitacao_Request();

		/**
		 * The meta object literal for the '<em>int</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.DefaultCollaborationDiagram.impl.DefaultCollaborationDiagramPackageImpl#getint()
		 * @generated
		 */
		EDataType INT = eINSTANCE.getint();

	}

} //DefaultCollaborationDiagramPackage
