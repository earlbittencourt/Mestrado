/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>�permitidosuspenderoprograma Request</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#get�permitidosuspenderoprograma_Request()
 * @model interface="true" abstract="true"
 *        annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='\311permitidosuspenderoprograma?_Request'"
 * @generated
 */
public interface �permitidosuspenderoprograma_Request extends EObject {
} // �permitidosuspenderoprograma_Request
