/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cancelarsolicitacao Request</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getCancelarsolicitacao_Request()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Cancelarsolicitacao_Request extends EObject {
} // Cancelarsolicitacao_Request
