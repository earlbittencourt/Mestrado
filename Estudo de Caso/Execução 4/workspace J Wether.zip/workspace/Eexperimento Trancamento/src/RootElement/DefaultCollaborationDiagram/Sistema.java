/**
 */
package RootElement.DefaultCollaborationDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sistema</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getSistema()
 * @model
 * @generated
 */
public interface Sistema extends Discente, Oalunoestaemobservacao_Service, Oalunoestaemobservacao_Request, Disciplina_Request, �permitidosuspenderoprograma_Service, �permitidosuspenderoprograma_Request, Matricula_Request, Naoepermitidosuspenderoprograma_Service, Atividade_Request, Solicitacaoaprovada_Service, Solicitacaoaprovada_Request, Analisarsolicitacao_Service, Aguardarsetediaseefetivartrancamento_Service, Aguardarsetediaseefetivartrancamento_Request {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="RootElement.boolean" required="true" ordered="false" matriculaDataType="RootElement.DefaultCollaborationDiagram.int" matriculaRequired="true" matriculaOrdered="false" codigoDisciplinaDataType="RootElement.String" codigoDisciplinaRequired="true" codigoDisciplinaOrdered="false"
	 * @generated
	 */
	boolean Verificarquantidadedetrancamentos(int matricula, Object codigoDisciplina);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarseeoalunoeformandoeativo();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Aguardarsetediaseefetivartrancamento();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="RootElement.String" required="true" ordered="false" matriculaDataType="RootElement.DefaultCollaborationDiagram.int" matriculaRequired="true" matriculaOrdered="false"
	 * @generated
	 */
	Object Verificarnivelensino(int matricula);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarsolicitacao();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarnivelestudante();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificartempodecorrido();

} // Sistema
