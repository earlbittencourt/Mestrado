/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Oalunoestaemobservacao Request</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getOalunoestaemobservacao_Request()
 * @model interface="true" abstract="true"
 *        annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='Oalunoestaemobservacao?_Request'"
 * @generated
 */
public interface Oalunoestaemobservacao_Request extends EObject {
} // Oalunoestaemobservacao_Request
