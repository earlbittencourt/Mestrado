/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>�permitidosuspenderoprograma Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#get�permitidosuspenderoprograma_Service()
 * @model interface="true" abstract="true"
 *        annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='\311permitidosuspenderoprograma?_Service'"
 * @generated
 */
public interface �permitidosuspenderoprograma_Service extends EObject {
} // �permitidosuspenderoprograma_Service
