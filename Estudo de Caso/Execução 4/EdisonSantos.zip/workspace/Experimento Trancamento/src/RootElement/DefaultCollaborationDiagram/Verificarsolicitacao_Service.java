/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Verificarsolicitacao Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getVerificarsolicitacao_Service()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Verificarsolicitacao_Service extends EObject {
} // Verificarsolicitacao_Service
