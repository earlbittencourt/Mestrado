/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Verificarsolicitacao Request</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getVerificarsolicitacao_Request()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Verificarsolicitacao_Request extends EObject {
} // Verificarsolicitacao_Request
