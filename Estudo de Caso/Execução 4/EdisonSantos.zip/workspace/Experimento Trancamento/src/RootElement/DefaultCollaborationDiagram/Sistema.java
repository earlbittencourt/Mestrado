/**
 */
package RootElement.DefaultCollaborationDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sistema</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getSistema()
 * @model
 * @generated
 */
public interface Sistema extends Discente, Naoepermitidosuspenderoprograma_Service, Analisarsolicitacao_Service, Aguardarsetediaseefetivartrancamento_Service, Aguardarsetediaseefetivartrancamento_Request, Oalunoestaemobservacao_Service, Oalunoestaemobservacao_Request, null_Request, Solicitacaoaprovada_Service, Solicitacaoaprovada_Request, Verificarsolicitacao_Request {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarstatusdoaluno();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarquantidadedetrancamentos();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarsolicitacao();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Aguardarsetediaseefetivartrancamento();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Verificarnivelensino();

} // Sistema
