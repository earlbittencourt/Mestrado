/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Solicitartrancamento Request</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getSolicitartrancamento_Request()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Solicitartrancamento_Request extends EObject {
} // Solicitartrancamento_Request
