/**
 */
package RootElement.DefaultCollaborationDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>solitacaodeferida Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.DefaultCollaborationDiagram.DefaultCollaborationDiagramPackage#getsolitacaodeferida_Service()
 * @model interface="true" abstract="true"
 *        annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='solitacaodeferida?_Service'"
 * @generated
 */
public interface solitacaodeferida_Service extends EObject {
} // solitacaodeferida_Service
